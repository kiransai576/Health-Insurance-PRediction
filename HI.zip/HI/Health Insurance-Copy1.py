
# coding: utf-8

# In[1]:


#step1:importing libraries


# In[2]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# In[3]:


#step2:importing dataset


# In[4]:


dataset=pd.read_csv(r'C:\Users\User_01\Desktop\insurance.csv')
dataset


# In[5]:


type(dataset)


# In[6]:


dataset.isnull().any()


# In[7]:


x=dataset.iloc[:,0:6]
x


# In[8]:


x=dataset.iloc[:,0:6].values


# In[9]:


x


# In[10]:


y=dataset.iloc[:,-1:]
y


# In[11]:


y=dataset.iloc[:,-1:].values
y


# In[12]:


from sklearn.preprocessing import LabelEncoder
lb=LabelEncoder()


# In[13]:


x[:,1]=lb.fit_transform(x[:,1])
x


# In[14]:


x[:,4]=lb.fit_transform(x[:,4])
x


# In[15]:


x[:,5]=lb.fit_transform(x[:,5])
x


# In[16]:


from sklearn.preprocessing import OneHotEncoder
oh=OneHotEncoder(categorical_features=[5])
x=oh.fit_transform(x).toarray()


# In[17]:


x


# In[18]:


x=x[:,1:]
x


# In[19]:


x.shape


# In[20]:


from sklearn.model_selection import train_test_split


# In[21]:


x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)


# In[22]:


x_test


# In[23]:


plt.scatter(x_train[:,5],y_train)


# In[24]:


from sklearn.linear_model import LinearRegression


# In[25]:


mr=LinearRegression()


# In[26]:


mr.fit(x_train,y_train)


# In[27]:


y_predict=mr.predict(x_test)
y_predict


# In[28]:


y_test


# In[29]:


mr.predict([[0. ,  0. ,  1. , 52. ,  1. , 30.2,  1. ,  0.]])


# In[30]:


from sklearn.metrics import r2_score


# In[31]:


r2_score(y_test,y_predict)


# # Logistic regression

# In[44]:


lb_y=LabelEncoder()
y=lb_y.fit_transform(y)
y


# In[45]:


from sklearn.model_selection import train_test_split


# In[46]:


x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)


# In[47]:


x_test


# In[48]:


np.shape(x_test)


# In[49]:


x_test.shape


# In[50]:


x_train.shape


# In[51]:


x_train


# In[52]:


from sklearn.preprocessing import StandardScaler
sc=StandardScaler()
x_train=sc.fit_transform(x_train)
x_test=sc.transform(x_test)


# In[53]:


x_train


# In[54]:


x_test


# In[55]:


from sklearn.linear_model import LogisticRegression
classifier =LogisticRegression()
classifier.fit(x_train,y_train)


# In[56]:


y_predict=classifier.predict(x_test)
y_predict


# In[59]:


from sklearn.metrics import r2_score


# In[60]:


r2_score(y_test,y_predict)


# In[61]:


from sklearn.preprocessing import StandardScaler
sc=StandardScaler()
x_train=sc.fit_transform(x_train)
x_test=sc.transform(x_test)


# In[62]:


x_train


# In[63]:


x_test


# # Decision tree

# In[82]:


from sklearn.tree import DecisionTreeRegressor
regressor= DecisionTreeRegressor(random_state=0)
regressor.fit(x_train,y_train)


# In[83]:


y_predict =regressor.predict(x_test)


# In[84]:


y_predict


# In[88]:


regressor.predict([[0.   ,  0.   ,  1.   , 19.   ,  0.   , 27.9  ,  0.   ,  1.]])


# In[91]:


from sklearn.metrics import r2_score
r2_score(y_test,y_predict)


# # Random FOREST

# In[94]:


from sklearn.ensemble import RandomForestRegressor
classifier=RandomForestRegressor(random_state=0)


# In[95]:


classifier.fit(x_train,y_train)


# In[96]:


y_predict=classifier.predict(x_test)
y_predict


# In[100]:


from sklearn.metrics import r2_score


# In[101]:


r2_score(y_test,y_predict)

